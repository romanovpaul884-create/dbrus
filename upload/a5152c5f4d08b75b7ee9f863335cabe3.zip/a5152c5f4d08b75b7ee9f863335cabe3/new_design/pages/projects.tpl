{include 'file:new_design/main/meta.tpl'}
{include 'file:new_design/main/header.tpl'}
<main class="main-wrapper">
    <section class="projects-main">
        <div class="container">
            {'!pdoCrumbs' | snippet : [
                'showHome' => 1,
                'tplWrapper' => '@INLINE <div class="breadcrumbs-row"><ol itemscope="" itemtype="http://schema.org/BreadcrumbList">{$output}</ol></div>',
                'tpl' => '@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a href="{$link}" itemprop="item"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></a></li>',
                'tplCurrent' => '@INLINE <li><span itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></span></li>'
            ]}
            <div class="projects-main__content">
                <h1 class="page-title">{$_modx->resource.pagetitle}</h1>
                <div class="section-wrapper msearch2" id="mse2_mfilter">
                    {'!mFilter2' | snippet : [
                    'paginator'=>'pdoPage',
                    'element' => 'pdoResources',
                    'includeTVs' => 'house_popular,house_name,house_namem,house_floors_upd,house_style,house_size,house_square,house_cost,built_house_type',
                    'loadModels' => 'ms2gallery',
                    'parents' => '2',
                    'limit' => '16',
                    'filters' => 'tv|house_size, tv|house_floors_upd, tv|house_style, tv|house_namem',
                    'aliases' => '
						tv|house_cost==cost,
						tv|house_floors_upd==floors,
						tv|house_size==size,
						tv|house_style==style,
						tv|house_namem==name,
					',
                    'tplOuter' => '@FILE new_design/mfilter/mFilter_houses.Outer.tpl',
                    'tplFilter.outer.default' => '@FILE templates/new/mfilter/mFilter2.filter.outer.tpl',
                    'tplFilter.row.default' => '@FILE templates/new/mfilter/mFilter2.filter.select.tpl',
                    'tpl' => '@FILE new_design/tpls/productItem_project.tpl',
                    'leftJoin' => [
                    "catalog" => [
                    "class" => "msResourceFile",
                    "alias" => "catalog",
                    "on" => "catalog.resource_id = modResource.id  AND catalog.rank = 0 AND catalog.path LIKE '%/catalog/%'"
                    ],
                    ],
                    'select' => ["catalog" => "catalog.url as catalog", "modResource" => "*"],
                    'tplPageWrapper' => '@INLINE <ul class="pagination-list">{$first}{$prev}{$pages}{$next}{$last}</ul>',
                    'tplPage' => '@INLINE <li><a href="{$href}" class="">{$pageNo}</a></li>',
                    'tplPageActive' => '@INLINE <li class="active"><a href="{$href}">{$pageNo}</a></li>',
                    'tplPageFirst' => '@INLINE <li class="first"><a href="{$href}">[[%pdopage_first]]</a></li>',
                    'tplPageLast' => '@INLINE <li class="last"><a href="{$href}">[[%pdopage_last]]</a></li>',
                    'tplPagePrev' => '@INLINE <li class="prev"><a href="{$href}">Предыдущая</a></li>',
                    'tplPageNext' => '@INLINE <li class="next"><a href="{$href}">Следующая</a></li>',
                    'tplPageSkip' => '@INLINE ',
                    'tplPageFirstEmpty' => '@INLINE <li class="first disable"><a href="{$href}">[[%pdopage_first]]</a></li>',
                    'tplPageLastEmpty' => '@INLINE <li class="last disable"><a href="{$href}">[[%pdopage_last]]</a></li>',
                    'tplPagePrevEmpty' => '@INLINE <li class="prev disable"><a href="{$href}">Предыдущая</a></li>',
                    'tplPageNextEmpty' => '@INLINE <li class="next disable"><a href="{$href}">Следующая</a></li>',
                    ]}
                </div>
                <div class="mse2_pagination pagination-row">
                    {'page.nav' | placeholder}
                </div>
            </div>
        </div>
    </section>
    <section class="equipment-section">
        <div class="container">
            <h2 class="section-title">{1 | resource: 'complect_title'}</h2>
            <div class="equipment-section__content">
                <div class="equipment-slider js-equipment-slider swiper">
                    <div class="swiper-wrapper">
                        {set $slides = json_decode(1 | resource: 'complect_descr', true)}
                        {foreach $slides as $slide}
                            <div class="swiper-slide">
                                <div class="equipment-item">
                                    <div class="image-block">
                                        <div class="image-wrapper">
                                            <picture>
                                                <source srcset="{$slide.item_image | phpthumbon: "w=215&h=215&q=95&f=webp"}" type="image/webp">
                                                <img src="{$slide.item_image | phpthumbon: "w=215&h=215&q=95"}" alt="image" class="item-image">
                                            </picture>
                                        </div>
                                        <div class="image-descr">
                                            {if $slide.item_price}
                                                <span class="price-value" data-saving="Ваша экономия">{$slide.item_price}</span>
                                            {/if}
                                            <h3 class="item-title">{$slide.item_title}</h3>
                                            {if $slide.item_subtitle}
                                                <p>{$slide.item_subtitle}</p>
                                            {/if}
                                        </div>
                                    </div>
                                    {if $slide.item_descr}
                                        <div class="descr-block">
                                            {$slide.item_descr}
                                        </div>
                                    {/if}
                                </div>
                            </div>
                        {/foreach}
                    </div>
                    <div class="slider-pagination"></div>
                </div>
            </div>
            <div class="equipment-section__info">
                <div class="info-title">
                    {1 | resource: 'contacts_info_title'}
                </div>
                <a href="{3 | url}" class="info-link btn btn-arrow">
                    <span class="btn-txt">Подробнее об акциях</span>
                    <span class="icon icon-btn_arrow"></span>
                </a>
            </div>
        </div>
    </section>
</main>
{include 'file:new_design/main/footer.tpl'}
{include 'file:new_design/main/modals.tpl'}
{include 'file:new_design/main/scripts.tpl'}
