{include 'file:new_design/main/meta.tpl'}
{include 'file:new_design/main/header.tpl'}
<main class="main-wrapper">
    <section class="faq-main">
        <div class="container">
            {'!pdoCrumbs' | snippet : [
                'showHome' => 1,
                'tplWrapper' => '@INLINE <div class="breadcrumbs-row"><ol itemscope="" itemtype="http://schema.org/BreadcrumbList">{$output}</ol></div>',
                'tpl' => '@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a href="{$link}" itemprop="item"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></a></li>',
                'tplCurrent' => '@INLINE <li><span itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></span></li>'
            ]}
            <div class="faq-main__content">
                <h1 class="page-title">{$_modx->resource.pagetitle}</h1>
                {set $faq = json_decode($_modx->resource.faq_wrapper, true)}
                <div class="faq-wrapper">
                    <div class="left-side">
                        <div class="categories-block">
                            <span class="current-value js-category-btn">{$faq[0]['item_category']}</span>
                            <ul class="categories-list">
                                {foreach $faq as $idx => $faq_item}
                                    <li><button type="button" class="js-faq-tab {if $idx == 0}active{/if}" data-tab="{$idx}">{$faq_item.item_category}</button></li>
                                {/foreach}
                            </ul>
                        </div>
                    </div>
                    <div class="right-side">
                        {foreach $faq as $idx => $faq_item}
                            <div class="category-tab {if $idx == 0}active{/if}" data-tab="{$idx}">
                                <div class="faq-list">
                                    {set $list = json_decode($faq_item.item_list, true)}
                                    {foreach $list as $idx => $item}
                                        <div class="faq-item {if $idx == 0}active{/if}">
                                            <h3 class="item-title js-faq-link">{$item.item_title}</h3>
                                            <div class="item-descr" {if $idx == 0}style="display: block;"{/if}>
                                                {$item.item_descr}
                                            </div>
                                            <span class="item-link js-faq-link"><span class="icon icon-close"></span></span>
                                        </div>
                                    {/foreach}
                                </div>
                            </div>
                        {/foreach}
                    </div>
                </div>
            </div>
        </div>
    </section>
    {include 'file:new_design/sections/tags.tpl'}
</main>
{include 'file:new_design/main/footer.tpl'}
{include 'file:new_design/main/modals.tpl'}
{include 'file:new_design/main/scripts.tpl'}
