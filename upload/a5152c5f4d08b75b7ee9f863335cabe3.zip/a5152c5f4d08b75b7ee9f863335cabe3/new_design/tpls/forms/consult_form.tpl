<form action="" class="form-content modal-content js-form-check">
    {csrf_field()}
    {'!utmMark' | snippet : []}
    <input type="hidden" name="project" value="{$_modx->resource.pagetitle | escape:'html'}">
    <input type="hidden" name="subject" value="Заявка с проекта">
    <input type="hidden" name="subjectcase" value="Записаться на экскурсию">
    <input type="text" name="call_message" class="input-style call_message" placeholder="" style="display: none;">
    <input type="hidden" name="check[]" value="">
    <div class="left-side">
        <div class="text-item active" data-type="9">
            <p>Вы сможете посмотреть дом № 9, оценить качество постройки, задать все интересующие вопросы. Дом находится по адресу:</p>
            <p>г. Москва, Каширское ш., вл.. 63к.1, Выставочный дом № 9, № 17 (м.Домодедовская)</p>
        </div>
        <div class="text-item" data-type="17">
            <p>Вы&nbsp;сможете посмотреть дом № 17 в&nbsp;современном стиле, оценить качество постройки, задать все интересующие вопросы. Адрес:</p>
            <p>г. Москва, каширское ш., вл.&nbsp;63к.1, выставочный дом № 17 (м.Домодедовская)</p>
        </div>
        <div class="text-item" data-type="917">
            <p>Вы&nbsp;сможете посмотреть дома № 9 и&nbsp;№ 17, оценить качество постройки, задать все интересующие вопросы. Дома находятся по&nbsp;адресу:</p>
            <p>г. Москва, каширское ш., вл.&nbsp;63к.1, выставочный дом № 9, № 17 (м.Домодедовская)</p>
        </div>
        <div class="text-item" data-type="build">
            <p>Вы&nbsp;сможете посмотреть процесс стройки, оценить качество, задать все интересующие вопросы нашему специалисту по&nbsp;технадзору</p>
            <p>Мы&nbsp;подберем ближайший к&nbsp;вам дом, и&nbsp;согласуем возможное время для&nbsp;посещения</p>
        </div>
        <div class="text-item" data-type="build9">
            <p>Вы&nbsp;сможете посмотреть дом № 9 и&nbsp;оценить качество. Адрес: г. Москва, каширское ш., вл.&nbsp;63к.1, выставочный дом № 9 (м.Домодедовская)</p>
            <p>Мы&nbsp;можем также показать вам ближайший строящийся дом&nbsp;— согласуем удобное время для&nbsp;посещения.</p>
        </div>
        <div class="text-item" data-type="build17">
            <p>Вы&nbsp;сможете посмотреть дом № 17 и&nbsp;оценить качество. Адрес: г. Москва, каширское ш., вл.&nbsp;63к.1, выставочный дом № 17. (м.Домодедовская)</p>
            <p>Мы&nbsp;можем также показать вам ближайший строящийся дом&nbsp;— согласуем удобное время для&nbsp;посещения.</p>
        </div>
        <div class="text-item" data-type="build917">
            <p>Вы&nbsp;сможете посмотреть дома № 9 и&nbsp;№ 17 и&nbsp;оценить качество. Адрес: г. Москва, каширское ш., вл.&nbsp;63к.1, выставочный дом № 9, № 17.</p>
            <p>Мы&nbsp;можем также показать вам ближайший строящийся дом&nbsp;— согласуем удобное время для&nbsp;посещения.</p>
        </div>
        <div class="text-item" data-type="none">
            <p>Вы&nbsp;сможете посмотреть два дома в&nbsp;разных стилях, строящийся объект, оценить качество лично и&nbsp;задать все интересующие вопросы&nbsp;— для&nbsp;этого оставьте заявку.</p>
        </div>
    </div>
    <div class="right-side">
        <div class="choose-type {if 'mp4' | in: $_modx->config['modal_video1']}js-video-hover{/if}">
            <label>
                <div class="video-block">
                    {if 'mp4' | in: $_modx->config['modal_video1']}
                        <video src="{$_modx->config['modal_video1']}#t=0.001" muted loop playsinline></video>
                    {else}
                        <img src="{$_modx->config['modal_video1']}" alt="image">
                    {/if}
                </div>
                <input type="checkbox" name="house" value="9" checked>
                <span class="label">Выставочный дом №9</span>
            </label>
        </div>
        <div class="choose-type {if 'mp4' | in: $_modx->config['modal_video2']}js-video-hover{/if}">
            <label>
                <div class="video-block">
                    {if 'mp4' | in: $_modx->config['modal_video2']}
                        <video src="{$_modx->config['modal_video2']}#t=0.001" muted loop playsinline></video>
                    {else}
                        <img src="{$_modx->config['modal_video2']}" alt="image">
                    {/if}
                </div>
                <input type="checkbox" name="house" value="17">
                <span class="label">Выставочный дом №17</span>
            </label>
        </div>
        <div class="choose-type {if 'mp4' | in: $_modx->config['modal_video3']}js-video-hover{/if}">
            <label>
                <div class="video-block">
                    {if 'mp4' | in: $_modx->config['modal_video3']}
                        <video src="{$_modx->config['modal_video3']}#t=0.001" muted loop playsinline></video>
                    {else}
                        <img src="{$_modx->config['modal_video3']}" alt="image">
                    {/if}
                </div>
                <input type="checkbox" name="house" value="build">
                <span class="label">Строящийся дом</span>
            </label>
        </div>
    </div>
    <div class="form-side">
        <div class="input-group">
            <label>
                <input type="text" name="name" class="input-style" placeholder="Ваше имя">
            </label>
        </div>
        <div class="input-group">
            <label>
                <input type="tel" name="phone" placeholder="Ваш телефон" class="input-style js-phone-input">
            </label>
        </div>
        <div class="input-group btn-group">
            <button type="submit" class="submit-btn primary-btn">
                <span class="btn-txt">Записаться на экскурсию</span>
                <span class="icon icon-btn_arrow"></span>
            </button>
        </div>
        <div class="input-group check-group">
            <label>
                <input type="checkbox" name="check" value="1">
                <span class="label"><p>Предоставляя свою личную информацию, соглашаюсь с <a href="{1768 | url}" target="_blank">Политикой конфиденциальности‍</a></p></span>
            </label>
        </div>
    </div>
</form>
