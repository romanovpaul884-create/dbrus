{include 'file:new_design/main/meta.tpl'}
{include 'file:new_design/main/header.tpl'}
<main class="main-wrapper">
	<section class="mortgage-main">
		<div class="container">
			{'!pdoCrumbs' | snippet : [
			    'showHome' => 1,
			    'tplWrapper' => '@INLINE <div class="breadcrumbs-row"><ol itemscope="" itemtype="http://schema.org/BreadcrumbList">{$output}</ol></div>',
			    'tpl' => '@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a href="{$link}" itemprop="item"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></a></li>',
			    'tplCurrent' => '@INLINE <li><span itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></span></li>'
			]}
			<div class="mortgage-main__content">
				<div class="left-side">
					<h1 class="page-title">{$_modx->resource.pagetitle}</h1>
					<div class="benefits-list">
						{set $benefits  = json_decode($_modx->resource.mortgage_list, true)}
						{foreach $benefits as $benefit}
							<div class="benefits-item">
								<span class="item-tag">{$benefit.item_tag}</span>
								<div class="item-descr">
									{$benefit.item_descr}
								</div>
							</div>
						{/foreach}
					</div>
				</div>
				<div class="right-side">
					<div class="image-wrapper">
						<picture>
							<source srcset="{$_modx->resource.mortgage_image | phpthumbon: "w=480&h=480&q=90&zc=1&f=webp"}" type="image/webp">
							<img src="{$_modx->resource.mortgage_image | phpthumbon: "w=480&h=480&q=90&zc=1"}" alt="image" class="main-image" loading="lazy">
						</picture>
					</div>
				</div>
				<div class="btn-side">
					<a href="#mortgage_modal" class="btn primary-btn main-btn js-simple-modal">
						<span class="btn-txt">Рассчитать ипотеку</span>
						<span class="icon icon-btn_arrow"></span>
					</a>
					<div class="partners-list">
						{set $banks = json_decode($_modx->resource.mortgage_payment, true)}
						{foreach $banks as $bank}
							<div class="partners-item">
								<img src="{$bank.item_image}" alt="image" class="item-image" loading="lazy">
							</div>
						{/foreach}
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="mortgage-section">
		<div class="container">
			<h2 class="section-title">{$_modx->resource.risk_title}</h2>
			<div class="benefits-list">
				{set $list  = json_decode($_modx->resource.risk_list, true)}
				{foreach $list as $item}
					<div class="benefits-item">
						<h3 class="item-title">{$item.item_title}</h3>
						<div class="item-descr">
							{$item.item_descr}
						</div>
					</div>
				{/foreach}
			</div>
			<div class="docs-list">
				{set $docs_list = json_decode($_modx->resource.risk_docs, true)}
				{foreach $docs_list as $doc}
					<a href="{$doc.item_image}" class="js-image-link docs-item">
						<div class="item-info">
							<span class="info-name">{$doc.item_type}</span>
							<span class="info-type">{$doc.item_org}</span>
						</div>
						<div class="image-wrapper">
							<picture>
								<source srcset="{$doc.item_image | phpthumbon: "w=84&h=118&q=90&zc=1&f=webp"}" type="image/webp">
								<img src="{$doc.item_image | phpthumbon: "w=84&h=118&q=90&zc=1"}" alt="image" class="item-image" loading="lazy">
							</picture>
						</div>
					</a>
				{/foreach}
			</div>
		</div>
	</section>
	<section class="programm-section">
		<div class="container">
			<h2 class="section-title">{$_modx->resource.programm_title}</h2>
			<div class="programm-section__content">
				<div class="image-side">
					<picture>
						<source srcset="/assets/template/new_design/images/common/main/programm_image.webp" type="image/webp"></source>
						<img src="/assets/template/new_design/images/common/main/programm_image.png" alt="image" class="programm-image" loading="lazy">
					</picture>
				</div>
				<div class="descr-side">
					{set $programms = json_decode($_modx->resource.programm_list, true)}

					<span class="programm-current js-programm-current">{$programms[0].item_title}</span>
					<ul class="links-list">
						{foreach $programms as $index => $programm}
							<li><a href="javascript:void(0);" class="js-programm-link {if $index == 0}active{/if}" data-tab="{$index + 1}">{$programm.item_title}</a></li>
						{/foreach}
					</ul>
					<div class="tabs-list">
						{foreach $programms as $index => $tab}
							<div class="tabs-item {if $index == 0}active{/if}" data-tab="{$index + 1}">
								<div class="content-wrapper">
									{set $list = json_decode($tab.item_list, true)}
									{foreach $list as $item}
										<div class="content-column">
											<span class="column-tag">{$item.item_title}</span>
											<div class="column-descr">
												{$item.item_descr}
											</div>
										</div>
									{/foreach}
								</div>
								<div class="btn-row">
									<a href="#mortgage_modal" class="order-btn btn btn-arrow js-simple-modal">
										<span class="btn-txt">Оставить заявку</span>
										<span class="icon icon-btn_arrow"></span>
									</a>
								</div>
							</div>
						{/foreach}
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="certificate-section">
		<div class="container">
			<h2 class="section-title">{$_modx->resource.matsert_title}</h2>
			<div class="image-wrapper">
				<picture>
					<source srcset="/assets/template/new_design/images/common/main/sert_bg.webp" type="image/webp"></source>
					<img src="/assets/template/new_design/images/common/main/sert_bg.jpg" alt="image" class="certificate-image" loading="lazy">
				</picture>
			</div>
			<div class="certificate-section__content">
				<div class="certificate-link">
					<div class="image-wrapper">
						<picture>
							<source srcset="{$_modx->resource.matsert_image | phpthumbon: "w=128&h=180&q=90&zc=1&f=webp"}" type="image/webp">
							<img src="{$_modx->resource.matsert_image | phpthumbon: "w=128&h=180&q=90&zc=1"}" alt="image" class="link-image" loading="lazy">
						</picture>
					</div>
				</div>
				<div class="certificate-info">
					<div class="info-descr">
						{$_modx->resource.matsert_descr}
					</div>
					{if $_modx->resource.matsert_link}
						<a href="{$_modx->resource.matsert_link | url}" class="btn primary-btn more-btn">
							<span class="btn-txt">{$_modx->resource.matsert_link_text}</span>
							<span class="icon icon-btn_arrow"></span>
						</a>
					{/if}
				</div>
			</div>
			<div class="decor-block" data-block="1"></div>
			<div class="decor-block" data-block="2"></div>
		</div>
	</section>
	{if $_modx->resource.build_faq}
	    <section class="faq-section">
		<div class="container">
			<h2 class="section-title">{$_modx->resource.build_title}</h2>
			<div class="faq-section__content">
				<div class="faq-list">
					{set $faq_list  = json_decode($_modx->resource.build_faq, true)}
					{foreach $faq_list as $index => $faq_item}
						<div class="faq-item {if $index == 0}active{/if}">
							<h3 class="item-title js-faq-link">{$faq_item.item_title}</h3>
							<div class="item-descr" {if $index == 0}style="display: block;"{/if}>
								{$faq_item.item_descr}
							</div>
							<span class="item-link js-faq-link"><span class="icon icon-close"></span></span>
						</div>
					{/foreach}
				</div>
			</div>
		</div>
	</section>
	{/if}
	{include 'file:new_design/sections/faq.tpl'}
	{include 'file:new_design/sections/tags.tpl'}
</main>
{include 'file:new_design/main/footer.tpl'}
{include 'file:new_design/main/modals.tpl'}
{include 'file:new_design/main/scripts.tpl'}
