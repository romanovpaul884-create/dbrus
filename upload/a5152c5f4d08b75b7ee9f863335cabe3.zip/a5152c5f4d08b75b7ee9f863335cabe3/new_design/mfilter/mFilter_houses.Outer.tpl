<div class="catalog-filter js-form-wrapper">
    <form action="{$_modx->resourse.id | url}" method="post" id="mse2_filters" class="js-filter-form filter-form">
        {$filters}
    </form>
    <div class="sort-row js-check-list">
        <a href="javascript:void(0);" class="show-link js-show-list" style="display: none;"><i class="icon icon-dots"></i></a>
        <a href="javascript:void(0);" class="clean-link js-clean-list" style="display: none;">очистить все</a>
        <div class="sort-block js-custom-select">
            <a href="javascript:void(0);" type="button" class="sort-link js-current-value">Отсортировать по цене</a>
            <div class="list-wrapper">
                <ul class="sort-list" id="mse2_sort">
                    <li><a href="#" data-sort="resource|min_price:asc">Цена по возростанию</a></li>
                    <li><a href="#" data-sort="resource|min_price:desc">Цена по убыванию</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div id="mse2_results" class="catalog-list">
    {$results}
</div>
