{set $questions = json_decode($_modx->resource.faq_list, true)}
{if $questions | length > 0}
	<section class="faq-section">
		<div class="container">
			<h2 class="section-title">{$_modx->resource.faq_title}</h2>
			<div class="faq-section__content">
				<div class="faq-list">
					{foreach $questions as $idx => $question}
						<div class="faq-item {if $idx == 0}active{/if}">
							<h3 class="item-title js-faq-link">{$question.item_title}</h3>
							<div class="item-descr" {if $idx == 0}style="display: block;"{/if}>
								{$question.item_descr}
							</div>
							<span class="item-link js-faq-link"><span class="icon icon-close"></span></span>
						</div>
					{/foreach}
				</div>
			</div>
		</div>
	</section>
{/if}