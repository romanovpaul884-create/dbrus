<form action="" class="form-content modal-content js-form-check">
    {csrf_field()}
    {'!utmMark' | snippet : []}
    <input type="hidden" name="project" value="{$_modx->resource.pagetitle | escape:'html'}">
    <input type="hidden" name="subject" value="Заявка с проекта">
    <input type="hidden" name="subjectcase" value="Записаться на экскурсию">
    <input type="text" name="call_message" class="input-style call_message" placeholder="" style="display: none;">
    <input type="hidden" name="check[]" value="">
    <div class="left-side">
        <div class="text-item active" data-type="9">
            <p>ВЫ СМОЖЕТЕ ПОСМОТРЕТЬ ДОМ № 9 В КЛАССИЧЕСКОМ СТИЛЕ, ОЦЕНИТЬ КАЧЕСТВО ПОСТРОЙКИ, ЗАДАТЬ ВСЕ ИНТЕРЕСУЮЩИЕ ВОПРОСЫ. АДРЕС:</p>
            <p>Г.. МОСКВА, КАШИРСКОЕ Ш., ВЛ.. 63К.1, ВЫСТАВОЧНЫЙ ДОМ № 9 (М.ДОМОДЕДОВСКАЯ)</p>
        </div>
        <div class="text-item" data-type="17">
            <p>ВЫ СМОЖЕТЕ ПОСМОТРЕТЬ ДОМ № 17 В СОВРЕМЕННОМ СТИЛЕ, ОЦЕНИТЬ КАЧЕСТВО ПОСТРОЙКИ, ЗАДАТЬ ВСЕ ИНТЕРЕСУЮЩИЕ ВОПРОСЫ. АДРЕС:</p>
            <p>Г.. МОСКВА, КАШИРСКОЕ Ш., ВЛ.. 63К.1, ВЫСТАВОЧНЫЙ ДОМ № 17 (М.ДОМОДЕДОВСКАЯ)</p>
        </div>
        <div class="text-item" data-type="917">
            <p>ВЫ СМОЖЕТЕ ПОСМОТРЕТЬ ДОМА № 9 и № 17, ОЦЕНИТЬ КАЧЕСТВО ПОСТРОЙКИ, ЗАДАТЬ ВСЕ ИНТЕРЕСУЮЩИЕ ВОПРОСЫ. ДОМА НАХОДЯТСЯ ПО АДРЕСУ:</p>
            <p>Г.. МОСКВА, КАШИРСКОЕ Ш., ВЛ.. 63К.1, ВЫСТАВОЧНЫЙ ДОМ № 9, № 17 (М.ДОМОДЕДОВСКАЯ)</p>
        </div>
        <div class="text-item" data-type="build">
            <p>ВЫ СМОЖЕТЕ ПОСМОТРЕТЬ ПРОЦЕСС СТРОЙКИ, ОЦЕНИТЬ КАЧЕСТВО, ЗАДАТЬ ВСЕ ИНТЕРЕСУЮЩИЕ ВОПРОСЫ НАШЕМУ СПЕЦИАЛИСТУ ПО ТЕХНАДЗОРУ</p>
            <p>МЫ ПОДБЕРЕМ БЛИЖАЙШИЙ К ВАМ ДОМ, И СОГЛАСУЕМ ВОЗМОЖНОЕ ВРЕМЯ ДЛЯ ПОСЕЩЕНИЯ</p>
        </div>
        <div class="text-item" data-type="build9">
            <p>ВЫ СМОЖЕТЕ ПОСМОТРЕТЬ ДОМ № 9 И ОЦЕНИТЬ КАЧЕСТВО. АДРЕС: Г. МОСКВА, КАШИРСКОЕ Ш., ВЛ. 63К.1, ВЫСТАВОЧНЫЙ ДОМ № 9 (М.ДОМОДЕДОВСКАЯ)</p>
            <p>МЫ МОЖЕМ ТАКЖЕ ПОКАЗАТЬ ВАМ БЛИЖАЙШИЙ СТРОЯЩИЙСЯ ДОМ — СОГЛАСУЕМ УДОБНОЕ ВРЕМЯ ДЛЯ ПОСЕЩЕНИЯ.</p>
        </div>
        <div class="text-item" data-type="build17">
            <p>ВЫ СМОЖЕТЕ ПОСМОТРЕТЬ ДОМ № 17 И ОЦЕНИТЬ КАЧЕСТВО. АДРЕС: Г. МОСКВА, КАШИРСКОЕ Ш., ВЛ. 63К.1, ВЫСТАВОЧНЫЙ ДОМ № 17. (М.ДОМОДЕДОВСКАЯ)</p>
            <p>МЫ МОЖЕМ ТАКЖЕ ПОКАЗАТЬ ВАМ БЛИЖАЙШИЙ СТРОЯЩИЙСЯ ДОМ — СОГЛАСУЕМ УДОБНОЕ ВРЕМЯ ДЛЯ ПОСЕЩЕНИЯ.</p>
        </div>
        <div class="text-item" data-type="build917">
            <p>ВЫ СМОЖЕТЕ ПОСМОТРЕТЬ ДОМА № 9 И № 17 И ОЦЕНИТЬ КАЧЕСТВО. АДРЕС: Г. МОСКВА, КАШИРСКОЕ Ш., ВЛ. 63К.1, ВЫСТАВОЧНЫЙ ДОМ № 9, № 17.</p>
            <p>МЫ МОЖЕМ ТАКЖЕ ПОКАЗАТЬ ВАМ БЛИЖАЙШИЙ СТРОЯЩИЙСЯ ДОМ — СОГЛАСУЕМ УДОБНОЕ ВРЕМЯ ДЛЯ ПОСЕЩЕНИЯ.</p>
        </div>
        <div class="text-item" data-type="none">
            <p>Вы сможете посмотреть два дома в разных стилях, строящийся объект, оценить качество лично и задать все интересующие вопросы — для этого оставьте заявку.</p>
        </div>
    </div>
    <div class="right-side">
        <div class="choose-type {if 'mp4' | in: $_modx->config['modal_video1']}js-video-hover{/if}">
            <label>
                <div class="video-block">
                    {if 'mp4' | in: $_modx->config['modal_video1']}
                        <video src="{$_modx->config['modal_video1']}#t=0.001" muted loop playsinline></video>
                    {else}
                        <img src="{$_modx->config['modal_video1']}" alt="image">
                    {/if}
                </div>
                <input type="checkbox" name="house" value="9" checked>
                <span class="label">Выставочный дом №9</span>
            </label>
        </div>
        <div class="choose-type {if 'mp4' | in: $_modx->config['modal_video2']}js-video-hover{/if}">
            <label>
                <div class="video-block">
                    {if 'mp4' | in: $_modx->config['modal_video2']}
                        <video src="{$_modx->config['modal_video2']}#t=0.001" muted loop playsinline></video>
                    {else}
                        <img src="{$_modx->config['modal_video2']}" alt="image">
                    {/if}
                </div>
                <input type="checkbox" name="house" value="17">
                <span class="label">Выставочный дом №17</span>
            </label>
        </div>
        <div class="choose-type {if 'mp4' | in: $_modx->config['modal_video3']}js-video-hover{/if}">
            <label>
                <div class="video-block">
                    {if 'mp4' | in: $_modx->config['modal_video3']}
                        <video src="{$_modx->config['modal_video3']}#t=0.001" muted loop playsinline></video>
                    {else}
                        <img src="{$_modx->config['modal_video3']}" alt="image">
                    {/if}
                </div>
                <input type="checkbox" name="house" value="build">
                <span class="label">Строящийся дом</span>
            </label>
        </div>
    </div>
    <div class="form-side">
        <div class="input-group">
            <label>
                <input type="text" name="name" class="input-style" placeholder="Ваше имя">
            </label>
        </div>
        <div class="input-group">
            <label>
                <input type="tel" name="phone" placeholder="Ваш телефон" class="input-style js-phone-input">
            </label>
        </div>
        <div class="input-group btn-group">
            <button type="submit" class="submit-btn primary-btn">
                <span class="btn-txt">Записаться на экскурсию</span>
                <span class="icon icon-btn_arrow"></span>
            </button>
        </div>
        <div class="input-group check-group">
            <label>
                <input type="checkbox" name="check" value="1">
                <span class="label"><p>Предоставляя свою личную информацию, соглашаюсь с <a href="{1768 | url}" target="_blank">Политикой конфиденциальности‍</a></p></span>
            </label>
        </div>
    </div>
</form>
