<form action="" class="js-form-check">
    {csrf_field()}
    {'!utmMark' | snippet : []}
    <input type="hidden" name="project" value="{$_modx->resource.pagetitle | escape:'html'}">
    <input type="hidden" name="subject" value="Заявка с проекта">
    <input type="hidden" name="subjectcase" value="Рассчитать ипотеку">
    <input type="text" name="call_message" class="input-style call_message" placeholder="" style="display: none;">
    <input type="hidden" name="check[]" value="">

    <div class="input-group">
        <label>
            <input type="text" name="name" class="input-style" placeholder="Ваше имя">
        </label>
    </div>
    <div class="input-group">
        <label>
            <input type="tel" name="phone" placeholder="Ваш телефон" class="input-style js-phone-input">
        </label>
    </div>
    <div class="input-group check-group">
        <label>
            <input type="checkbox" name="check[]" value="1">
            <span class="label">
                <p>Предоставляя свою личную информацию, соглашаюсь с <a href="{1768 | url}" target="_blank">Политикой конфиденциальности</a></p>
            </span>
        </label>
    </div>
    <div class="input-group btn-group">
        <button type="submit" class="btn primary-btn submit-btn">
            <span class="btn-txt">Получить предложение</span>
            <span class="icon icon-btn_arrow"></span>
        </button>
    </div>
</form>
