<!DOCTYPE html>
<html lang="{$_modx->config['cultureKey']}">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<base href="{'site_url' | config}">
	<title>{'seoPro.title' | placeholder}</title>
	<meta name="description" content="[[*description]]" />
	<meta name="facebook-domain-verification" content="nuiddfmowjw22m97zrwawkgoni9ync" />
	<link rel="shortcut icon" href="{'favicon' | config}" type="image/x-icon">
	<meta property="og:image" content="/assets/images/dist/s_4_col_right_pic.png">

	<link rel="stylesheet" href="/assets/template/new_design/css/libs/lenis.css">
	<link rel="stylesheet" href="/assets/template/new_design/css/libs/swiper-bundle.css">
	<link rel="stylesheet" href="/assets/template/new_design/css/libs/magnific-popup.css">
	<link data-v="cache" rel="stylesheet" href="/assets/template/new_design/css/styles.css">
	
	<meta name="zen-verification" content="8b0tftgvPxcjR517KCwTDlO5rjENtCupZohQ7ErtDcTGUkGXk2JbGgd5CVEru5p3" />

	{ignore}
		<!-- Google Tag Manager -->
		<script>(function(w,d,s,l,i){ w[l]=w[l]||[];w[l].push({ 'gtm.start':
						new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
					j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
					'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
			})(window,document,'script','dataLayer','GTM-PSWMKVFN');</script>
		<!-- End Google Tag Manager -->
	{/ignore}
	<div class="chunck-metrika">[[$metrika]]</div>

</head>
<body>
