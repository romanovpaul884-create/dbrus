{include 'file:new_design/main/meta.tpl'}
{include 'file:new_design/main/header.tpl'}
<main class="main-wrapper">
	<section class="capital-main">
		<div class="container">
			{'!pdoCrumbs' | snippet : [
				'showHome' => 1,
				'tplWrapper' => '@INLINE <div class="breadcrumbs-row"><ol itemscope="" itemtype="http://schema.org/BreadcrumbList">{$output}</ol></div>',
				'tpl' => '@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a href="{$link}" itemprop="item"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></a></li>',
				'tplCurrent' => '@INLINE <li><span itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></span></li>'
			]}
			<div class="capital-main__content">
				<div class="left-side">
					<h1 class="page-title">{$_modx->resource.pagetitle}</h1>
				</div>
				<div class="right-side">
					<div class="image-wrapper">
						<picture>

							<source srcset="{$_modx->resource.capital_image | phpthumbon: "w=420&h=420&q=90&zc=1"}" media="(max-width: 575px)">
							<source srcset="{$_modx->resource.capital_image | phpthumbon: "w=320&h=320&q=90&zc=1"}" media="(max-width: 768px)">
							<img src="{$_modx->resource.capital_image | phpthumbon: "w=480&h=480&q=90&zc=1"}" alt="image" class="main-image" loading="lazy">
						</picture>
					</div>
				</div>
			</div>
			<div class="capital-main__info">
				<div class="left-side">
					{set $info = json_decode($_modx->resource.capital_info, true)}
					{foreach $info as $infoitem}
						<div class="info-item">
							<div class="icon">
								<img src="{$infoitem.item_icon}" alt="icon" class="icon-img " loading="lazy">
							</div>
							<div class="item-descr">
								<p>{$infoitem.item_title}</p>
							</div>
						</div>
					{/foreach}
				</div>
				<div class="right-side">
					{set $prices = json_decode($_modx->resource.capital_prices, true)}
					{foreach $prices as $idx => $price}
						<div class="type-item {if $idx == 0}active{/if}">
							<span class="item-tag">{$price.item_price}</span>
							<div class="item-descr">
								<p>{$price.item_title}</p>
							</div>
						</div>
					{/foreach}
					<a href="#capital_modal" class="btn primary-btn capital-btn js-simple-modal">
						<span class="btn-txt">Получить консультацию</span>
						<span class="icon icon-btn_arrow"></span>
					</a>
				</div>
			</div>
		</div>
	</section>
	<section class="use-section">
		<div class="container">
			<h2 class="section-title">{$_modx->resource.use_title}</h2>
			<div class="use-section__content">
				<div class="tabs-links">
					<a href="javascript:void(0);" data-tab="1" class="tabs-link js-use-link active">При оформлении ипотеки</a>
					<a href="javascript:void(0);" data-tab="2" class="tabs-link js-use-link">Для строительства дома</a>
				</div>
				<div class="tabs-list">
					<div class="tabs-item active" data-tab="1">
						<div class="faq-list">
							{set $applist = json_decode($_modx->resource.use_app, true)}
							{foreach $applist as $idx => $appitem}
								<div class="faq-item {if $idx == 0}active{/if}">
									<div class="item-title js-faq-link">{$appitem.item_title}</div>
									<div class="item-descr" {if $idx == 0}style="display: block;"{/if}>
										<div class="use-content">
											<div class="left-side">
												<div class="descr-block">
													{$appitem.item_descr}
												</div>
												{if $appitem.item_info}
												<div class="info-block">
													<p>{$appitem.item_info}</p>
												</div>
												{/if}
											</div>
											<div class="right-side">
												<div class="link-block js-help-block">
													<span class="block-title js-help-title">Нужна помощь?</span>
													<div class="block-descr">
														<p>Оставьте заявку — наш менеджер подберёт оптимальные условия в одном из трёх банков и поможет оформить документы.</p>
														<a href="#capital_modal" class="consult-btn js-simple-modal">
															<span class="btn-txt">Получить консультацию</span>
															<span class="icon icon-btn_arrow"></span>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>
									<span class="item-link js-faq-link"><span class="icon icon-close"></span></span>
								</div>
							{/foreach}
						</div>
					</div>
					<div class="tabs-item" data-tab="2">
						<div class="faq-list">
							{set $buildlist = json_decode($_modx->resource.use_build, true)}
							{foreach $buildlist as $idx => $builditem}
								<div class="faq-item {if $idx == 0}active{/if}">
									<div class="item-title js-faq-link">{$builditem.item_title}</div>
									<div class="item-descr" {if $idx == 0}style="display: block;"{/if}>
										<div class="use-content">
											<div class="left-side">
												<div class="descr-block">
													{$builditem.item_descr}
												</div>
												{if $builditem.item_info}
													<div class="info-block">
														<p>{$builditem.item_info}</p>
													</div>
												{/if}
											</div>
											<div class="right-side">
												<div class="link-block js-help-block">
													<span class="block-title js-help-title">Нужна помощь?</span>
													<div class="block-descr">
														<p>Оставьте заявку — наш менеджер подберёт оптимальные условия в одном из трёх банков и поможет оформить документы.</p>
														<a href="#capital_modal" class="consult-btn js-simple-modal">
															<span class="btn-txt">Получить консультацию</span>
															<span class="icon icon-btn_arrow"></span>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>
									<span class="item-link js-faq-link"><span class="icon icon-close"></span></span>
								</div>
							{/foreach}
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="get-section">
		<div class="container">
			<h2 class="section-title">{$_modx->resource.how_title}</h2>
			<div class="section-descr">
				{$_modx->resource.how_descr}
			</div>
			<div class="get-section__content">
				<div class="left-side">
					<div class="element-wrapper">
						<video src="{$_modx->resource.get_video}" autoplay muted loop playsinline class="get-el"></video>
					</div>
				</div>
				<div class="right-side">
					<div class="descr-list">
						{set $infolist = json_decode($_modx->resource.get_list, true)}
						{foreach $infolist as $infoitem}
							<div class="descr-item">
								<div class="descr-wrapper">
									<p>{$infoitem.item_title}</p>
								</div>
							</div>
						{/foreach}
					</div>
				</div>
			</div>
		</div>
	</section>
	{if $_modx->resource.build_faq}
		<section class="faq-section">
			<div class="container">
				<h2 class="section-title">{$_modx->resource.build_title}</h2>
				<div class="faq-section__content">
					<div class="faq-list">
						{set $faq_list  = json_decode($_modx->resource.build_faq, true)}
						{foreach $faq_list as $index => $faq_item}
							<div class="faq-item {if $index == 0}active{/if}">
								<h3 class="item-title js-faq-link">{$faq_item.item_title}</h3>
								<div class="item-descr" {if $index == 0}style="display: block;"{/if}>
									{$faq_item.item_descr}
								</div>
								<span class="item-link js-faq-link"><span class="icon icon-close"></span></span>
							</div>
						{/foreach}
					</div>
				</div>
			</div>
		</section>
	{/if}
	{include 'file:new_design/sections/faq.tpl'}
	{include 'file:new_design/sections/tags.tpl'}
</main>
{include 'file:new_design/main/footer.tpl'}
{include 'file:new_design/main/modals.tpl'}
{include 'file:new_design/main/scripts.tpl'}
