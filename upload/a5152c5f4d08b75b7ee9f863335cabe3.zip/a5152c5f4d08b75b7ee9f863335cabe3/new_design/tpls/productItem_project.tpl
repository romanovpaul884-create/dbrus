{set $product = $modx->getObject('modResource', $id)}
{set $comp_prices=json_decode($_modx->resource.complect_prices)}
{set $comp_prices = json_decode($product->getTVValue('complect_prices'), true)}
{set $sets = json_decode($product->getTVValue('sets'), true)}

<div class="product-item">
    <a href="{$uri}" class="item-link">
        <div class="image-block">
            <ul class="tag-list">
                {if $_pls['tv.house_popular']}<li>популярный</li>{/if}
            </ul>
            {'!ms2Gallery' | snippet : [
                'resources' => $id,
                'limit' => 5,
                'tpl' => 'tpl.ms2Gallery_custom'
            ]}
        </div>
        <div class="descr-block">
            <div class="item-name">
                <div class="item-title">{'replaceName' | snippet : [ 'title' => $pagetitle]}</div>
                {if 2 | resource: 'percent_offset'}
                {set $upd_price = '!updPrice' | snippet : [
                    'price' => $comp_prices[0][w200] | intval,
                    'koef' => 2 | resource: 'percent_offset'
                ]}
                    <div class="item-price" data-fm="{$min_price}">от {$upd_price | number : 0 : "." : " "} р.</div>
                {else}
                    <div class="item-price" data-fm="{$min_price}">от {$comp_prices[0][w200] | number : 0 : "." : " "} р.</div>
                {/if}
            </div>
            <div class="item-info">
                <div class="info-item house-type">{$_pls['tv.house_style']}</div>
                <div class="info-item floor-type">{$_pls['tv.house_floors_upd']}</div>
                <div class="info-item square-type">{$house_square} м<sup>2</sup></div>
                <div class="info-item size-type">{$house_size}</div>
            </div>
        </div>
    </a>
</div>
