{if $id == 921}
    <li class="menu-list__item submenu-item js-subitem-link">
        <span class="item-name">{$pagetitle}</span>
        <div class="submenu-wrapper">
            <ul class="submenu-list">
                <li><a href="{$link}">{$menutitle}</a></li>
                <li><a href="{1713 | url}">{1713 | resource: 'menutitle'}</a></li>
                <li><a href="{22 | url}">{22 | resource: 'menutitle'}</a></li>
                <li><a href="{920 | url}">{920 | resource: 'menutitle'}</a></li>
                <li><a href="{10 | url}">{10 | resource: 'menutitle'}</a></li>
            </ul>
        </div>
    </li>
{elseif $id == 919}
    <li class="menu-list__item submenu-item js-subitem-link">
        <span class="item-name">Ипотека</span>
        <div class="submenu-wrapper">
            <ul class="submenu-list">
                <li><a href="{919 | url}">Программы ипотеки</a></li>
                <li><a href="{1922 | url}">Эскроу</a></li>
                <li><a href="{922 | url}">Маткапитал</a></li>
            </ul>
        </div>
    </li>
{else}
    <li class="menu-list__item">
        <a class="menu-list__link {$classnames}" href="{$link}">{$menutitle}</a>
    </li>
{/if}
