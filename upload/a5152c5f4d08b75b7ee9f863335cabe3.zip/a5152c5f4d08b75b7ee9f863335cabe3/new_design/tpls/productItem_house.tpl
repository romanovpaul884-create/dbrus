<div class="product-item">
    <a href="{$uri}" class="item-link">
        <div class="image-block">
            <ul class="tag-list">
                {if $_pls['tv.house_popular']}<li>популярный</li>{/if}
            </ul>
            {'!ms2Gallery' | snippet : [
                'resources' => $id,
                'limit' => 5,
                'tpl' => 'tpl.ms2Gallery_custom'
            ]}
        </div>
        <div class="descr-block">
            <div class="item-name">
                <div class="item-title"><span>{$_pls['tv.built_house_type']}</span> {$_pls['tv.house_name']}</div>
                {if $_pls['tv.house_cost']}
                    <div class="item-price">{$_pls['tv.house_cost'] | number : 0 : "." : " "} р.</div>
                {/if}
            </div>
            <div class="item-info">
                <div class="info-item house-type">{$_pls['tv.house_style']}</div>
                <div class="info-item floor-type">{$_pls['tv.house_floors_upd']}</div>
                <div class="info-item square-type">{$_pls['tv.house_square']} м<sup>2</sup></div>
                <div class="info-item size-type">{$_pls['tv.house_size']}</div>
            </div>
            {if $_pls['tv.house_build_time']}
                <div class="item-add">
                    <span class="time">{$_pls['tv.house_build_time']}</span>
                </div>
            {/if}
        </div>
    </a>
</div>
