{include 'file:new_design/main/meta.tpl'}
{include 'file:new_design/main/header.tpl'}
<main class="main-wrapper">
    <section class="houses-main">
        <div class="container">
            {'!pdoCrumbs' | snippet : [
                'showHome' => 1,
                'tplWrapper' => '@INLINE <div class="breadcrumbs-row"><ol itemscope="" itemtype="http://schema.org/BreadcrumbList">{$output}</ol></div>',
                'tpl' => '@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a href="{$link}" itemprop="item"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></a></li>',
                'tplCurrent' => '@INLINE <li><span itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><span itemprop="name">{$menutitle}</span><meta itemprop="position" content="{$idx}"></span></li>'
            ]}
            <div class="houses-main__content">
                <h1 class="page-title">{$_modx->resource.pagetitle}</h1>
                <div id="pdopage" class="projects-list">
                    {'!pdoPage' | snippet : [
                        'includeTVs' => 'built_house_type,house_name,house_floors_upd,house_style,house_size,house_square,house_cost,house_build_time',
                        'loadModels' => 'ms2gallery',
                        'parents' => $_modx->resource.id,
                        'includeContent' => 1,
                        'sortby' => 'menuindex',
                        'limit' => 16,
                        'sortdir' => 'asc',
                        'tpl' => '@FILE new_design/tpls/productItem_house.tpl',
                        'leftJoin' => [
                            "catalog" => [
                                "class" => "msResourceFile",
                                "alias" => "catalog",
                                "on" => "catalog.resource_id = modResource.id  AND catalog.rank = 0 AND catalog.path LIKE '%/catalog/%'"
                            ],
                        ],
                        'select' => ["catalog" => "catalog.url as catalog", "modResource" => "*"],
                        'tplPageWrapper' => '@INLINE <ul class="pagination-list">{$first}{$prev}{$pages}{$next}{$last}</ul>',
                        'tplPage' => '@INLINE <li><a href="{$href}" class="">{$pageNo}</a></li>',
                        'tplPageActive' => '@INLINE <li class="active"><a href="{$href}">{$pageNo}</a></li>',
                        'tplPageFirst' => '@INLINE <li class="first"><a href="{$href}">[[%pdopage_first]]</a></li>',
                        'tplPageLast' => '@INLINE <li class="last"><a href="{$href}">[[%pdopage_last]]</a></li>',
                        'tplPagePrev' => '@INLINE <li class="prev"><a href="{$href}">Предыдущая</a></li>',
                        'tplPageNext' => '@INLINE <li class="next"><a href="{$href}">Следующая</a></li>',
                        'tplPageSkip' => '@INLINE ',
                        'tplPageFirstEmpty' => '@INLINE <li class="first disable"><a href="{$href}">[[%pdopage_first]]</a></li>',
                        'tplPageLastEmpty' => '@INLINE <li class="last disable"><a href="{$href}">[[%pdopage_last]]</a></li>',
                        'tplPagePrevEmpty' => '@INLINE <li class="prev disable"><a href="{$href}">Предыдущая</a></li>',
                        'tplPageNextEmpty' => '@INLINE <li class="next disable"><a href="{$href}">Следующая</a></li>',
                    ]}
                </div>
                <div class="mse2_pagination pagination-row">
                    {'page.nav' | placeholder}
                </div>
            </div>
        </div>
    </section>
    <section class="consultation-section">
        <div class="container">
            <h2 class="section-title">Убедитесь в качестве лично, запишитесь на экскурсию</h2>
            {'!ajaxForm' | snippet : [
                'snippet' => 'formIt',
                'form' => '@FILE:new_design/tpls/forms/consult_form.tpl',
                'hooks' => 'csrf,email,FormItSaveForm,amoCRMAddContact',
                'emailSubject' => 'Записаться на экскурсию c сайта ' ~ 'site_name' | config,
                'emailTo' => 'site_email' | config,
                'emailFrom' => "front_email" | config,
                'validate' => 'name:required,phone:required,call_message:blank,check:required',
                'validationErrorMessage' => 'В форме содержатся ошибки!',
                'amoCRMmodxAmoFieldsEq' => 'name||phone||utm_source==UTM_SOURCE||utm_medium==UTM_MEDIUM||utm_term==UTM_TERM||utm_content==UTM_CONTENT||utm_campaign==UTM_CAMPAIGN||original_ref==569577||start_page==569579||ip==569581||url==569583||roistat==569585||roistat_referrer==569587||roistat_pos==569589||yclid==yclid||_ym_uid==558263',
                'successMessage' => 'Сообщение успешно отправлено',
                'emailTpl' => '@INLINE
						<p>Записаться на экскурсию {"site_name" | config}</p>
						<p><strong>Имя</strong> {$name}</p>
						<p><strong>Телефон</strong> {$phone}</p>
						<p><strong>Дом</strong> {$house}</p>
				'
            ]}
        </div>
    </section>
</main>
{include 'file:new_design/main/footer.tpl'}
{include 'file:new_design/main/modals.tpl'}
{include 'file:new_design/main/scripts.tpl'}
