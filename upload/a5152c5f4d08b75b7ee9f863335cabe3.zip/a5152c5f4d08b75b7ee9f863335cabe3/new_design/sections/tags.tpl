{set $tags = json_decode($_modx->resource.tags_list, true)}
{if $tags | length > 0}
	<section class="tags-section">
		<div class="container">
			<div class="tags-slider js-tags-slider swiper">
				<div class="swiper-wrapper">
					{foreach $tags as $tag}
						<div class="swiper-slide"><a href="{$tag.item_link}">{$tag.item_name}</a></div>
					{/foreach}
				</div>
				<div class="slider-navigation">
                    <a href="javascript:void(0);" class="nav-btn prev-btn"><span class="icon icon-btn_arrow"></span></a>
                    <a href="javascript:void(0);" class="nav-btn next-btn"><span class="icon icon-btn_arrow"></span></a>
                </div>
			</div>
		</div>
	</section>
{/if}