<div id="mortgage_modal" class="mortgage-modal modal-style mfp-with-anim mfp-hide">
	<div class="modal-wrapper">
		<a href="javascript:void(0);" class="js-modal-close close-btn"><span class="icon icon-close"></span></a>
		<div class="modal-title">Рассчитайте ипотеку</div>
		<div class="modal-descr">
			<p>Персональный кредитный менеджер подберёт лучшие решения из 3-х банков за 1 день с вероятностью одобрения в 99%</p>
		</div>
		<div class="modal-form">
			{'!ajaxForm' | snippet : [
				'snippet' => 'formIt',
				'form' => '@FILE:new_design/tpls/forms/mortgage_form.tpl',
				'hooks' => 'csrf,email,FormItSaveForm,amoCRMAddContact',
				'emailSubject' => 'Рассчитать ипотеку c сайта ' ~ 'site_name' | config,
				'emailTo' => 'site_email' | config,
				'emailFrom' => "front_email" | config,
				'validate' => 'name:required,phone:required,call_message:blank,check:required',
				'validationErrorMessage' => 'В форме содержатся ошибки!',
				'amoCRMmodxAmoFieldsEq' => 'name==name||phone==phone||project==569555||subject==569559||subjectcase==569561||utm_source==UTM_SOURCE||utm_medium==UTM_MEDIUM||utm_term==UTM_TERM||utm_content==UTM_CONTENT||utm_campaign==UTM_CAMPAIGN||original_ref==569577||start_page==569579||ip==569581||url==569583||roistat==569585||roistat_referrer==569587||roistat_pos==569589||yclid==yclid||_ym_uid==558263',
				'successMessage' => 'Сообщение успешно отправлено',
				'emailTpl' => '@INLINE
							<p>Рассчитать ипотеку {"site_name" | config}</p>
							<p><strong>Имя</strong> {$name}</p>
							<p><strong>Телефон</strong> {$phone}</p>
                        '
			]}
		</div>
	</div>
</div>
<div id="consultation_modal" class="consultation-modal modal-style mfp-with-anim mfp-hide">
	<div class="modal-wrapper">
		<a href="javascript:void(0);" class="js-modal-close close-btn"><span class="icon icon-close"></span></a>
		<div class="modal-title">Убедитесь в качестве лично, запишитесь на экскурсию</div>
		{'!ajaxForm' | snippet : [
			'snippet' => 'formIt',
			'form' => '@FILE:new_design/tpls/forms/excursion_form.tpl',
			'hooks' => 'csrf,email,FormItSaveForm,amoCRMAddContact',
			'emailSubject' => 'Записаться на экскурсию c сайта ' ~ 'site_name' | config,
			'emailTo' => 'site_email' | config,
			'emailFrom' => "front_email" | config,
			'validate' => 'name:required,phone:required,call_message:blank,check:required',
			'validationErrorMessage' => 'В форме содержатся ошибки!',
			'amoCRMmodxAmoFieldsEq' => 'name==name||phone==phone||project==569555||subject==569559||subjectcase==569561||utm_source==UTM_SOURCE||utm_medium==UTM_MEDIUM||utm_term==UTM_TERM||utm_content==UTM_CONTENT||utm_campaign==UTM_CAMPAIGN||original_ref==569577||start_page==569579||ip==569581||url==569583||roistat==569585||roistat_referrer==569587||roistat_pos==569589||yclid==yclid||_ym_uid==558263',
			'successMessage' => 'Сообщение успешно отправлено',
			'emailTpl' => '@INLINE
					<p>Записаться на экскурсию {"site_name" | config}</p>
					<p><strong>Имя</strong> {$name}</p>
					<p><strong>Телефон</strong> {$phone}</p>
					<p><strong>Дом</strong> {$house}</p>
			'
		]}
	</div>
</div>
<div id="capital_modal" class="capital-modal modal-style mfp-with-anim mfp-hide">
	<div class="modal-wrapper">
		<a href="javascript:void(0);" class="js-modal-close close-btn"><span class="icon icon-close"></span></a>
		<div class="modal-title">Консультация по маткапиталу</div>
		<div class="modal-descr">
			<p>Персональный кредитный менеджер объяснит, как применить материнский капитал при строительстве и поможет подобрать оптимальные условия в банке</p>
		</div>
		<div class="modal-form">
			{'!ajaxForm' | snippet : [
				'snippet' => 'formIt',
				'form' => '@FILE:new_design/tpls/forms/capital_form.tpl',
				'hooks' => 'csrf,email,FormItSaveForm,amoCRMAddContact',
				'emailSubject' => 'Консультация по маткапиталу c сайта ' ~ 'site_name' | config,
				'emailTo' => 'site_email' | config,
				'emailFrom' => "front_email" | config,
				'validate' => 'name:required,phone:required,call_message:blank,check:required',
				'validationErrorMessage' => 'В форме содержатся ошибки!',
				'amoCRMmodxAmoFieldsEq' => 'name||phone||utm_source==UTM_SOURCE||utm_medium==UTM_MEDIUM||utm_term==UTM_TERM||utm_content==UTM_CONTENT||utm_campaign==UTM_CAMPAIGN||original_ref==569577||start_page==569579||ip==569581||url==569583||roistat==569585||roistat_referrer==569587||roistat_pos==569589||yclid==yclid||_ym_uid==558263',
				'successMessage' => 'Сообщение успешно отправлено',
				'emailTpl' => '@INLINE
						<p>Консультация по маткапиталу {"site_name" | config}</p>
						<p><strong>Имя</strong> {$name}</p>
						<p><strong>Телефон</strong> {$phone}</p>
				'
			]}
		</div>
	</div>
</div>
